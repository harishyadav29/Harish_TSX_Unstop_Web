document.addEventListener('DOMContentLoaded', function() {
    // Set current year in footer
    document.getElementById('currentYear').textContent = new Date().getFullYear();

    // Mobile Navigation Toggle
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');

    if (hamburger) {
        hamburger.addEventListener('click', function() {
            hamburger.classList.toggle('active');
            navLinks.classList.toggle('active');
        });
    }

    // Close mobile menu when link is clicked
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.addEventListener('click', () => {
            hamburger.classList.remove('active');
            navLinks.classList.remove('active');
        });
    });

    // Profile Image Upload
    const profileImageUpload = document.getElementById('profileImageUpload');
    const profileImage = document.getElementById('profileImage');

    if (profileImageUpload && profileImage) {
        profileImageUpload.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(event) {
                    profileImage.src = event.target.result;
                    // Save to local storage
                    localStorage.setItem('profileImage', event.target.result);
                };
                reader.readAsDataURL(file);
            }
        });

        // Load saved profile image
        const savedProfileImage = localStorage.getItem('profileImage');
        if (savedProfileImage) {
            profileImage.src = savedProfileImage;
        }
    }

    // Project Image Upload
    document.querySelectorAll('.project-image-upload input').forEach(input => {
        input.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                const projectImage = this.closest('.project-image').querySelector('img');
                
                reader.onload = function(event) {
                    projectImage.src = event.target.result;
                };
                reader.readAsDataURL(file);
            }
        });
    });

    // Modal Functionality
    function openModal(modalId) {
        document.getElementById(modalId).style.display = 'flex';
    }

    function closeModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
    }

    // Close modals when clicking the X or outside the modal
    document.querySelectorAll('.close-modal').forEach(closeBtn => {
        closeBtn.addEventListener('click', function() {
            this.closest('.modal').style.display = 'none';
        });
    });

    window.addEventListener('click', function(e) {
        document.querySelectorAll('.modal').forEach(modal => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });
    });

    // Competency Modal
    const addCompetencyBtn = document.getElementById('addCompetencyBtn');
    const competencyModal = document.getElementById('competencyModal');
    const competencyForm = document.getElementById('competencyForm');
    const competenciesContainer = document.getElementById('competenciesContainer');

    if (addCompetencyBtn && competencyModal) {
        addCompetencyBtn.addEventListener('click', function() {
            openModal('competencyModal');
        });
    }

    if (competencyForm && competenciesContainer) {
        competencyForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const icon = document.getElementById('competencyIcon').value;
            const title = document.getElementById('competencyTitle').value;
            const description = document.getElementById('competencyDescription').value;
            
            const competencyElement = document.createElement('div');
            competencyElement.className = 'competency';
            competencyElement.innerHTML = `
                <i class="${icon}"></i>
                <h4>${title}</h4>
                <p>${description}</p>
            `;
            
            competenciesContainer.insertBefore(competencyElement, addCompetencyBtn);
            
            competencyForm.reset();
            closeModal('competencyModal');
        });
    }

    // Skill Modal and Management
    const skillModal = document.getElementById('skillModal');
    const skillForm = document.getElementById('skillForm');
    const addSkillBtns = document.querySelectorAll('.add-skill-btn');
    
    if (addSkillBtns.length && skillModal) {
        addSkillBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const category = this.dataset.category;
                document.getElementById('skillCategory').value = category;
                openModal('skillModal');
            });
        });
    }

    // Skill level slider value display
    const skillLevel = document.getElementById('skillLevel');
    const skillLevelValue = document.getElementById('skillLevelValue');
    
    if (skillLevel && skillLevelValue) {
        skillLevel.addEventListener('input', function() {
            skillLevelValue.textContent = this.value + '%';
        });
    }

    if (skillForm) {
        skillForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const category = document.getElementById('skillCategory').value;
            const name = document.getElementById('skillName').value;
            const level = document.getElementById('skillLevel').value;
            
            const skillItem = document.createElement('div');
            skillItem.className = 'skill-item';
            skillItem.innerHTML = `
                <div class="skill-info">
                    <span class="skill-name">${name}</span>
                    <span class="skill-level">${level}%</span>
                </div>
                <div class="skill-bar">
                    <div class="skill-progress" style="width: ${level}%;"></div>
                </div>
                <button class="delete-skill"><i class="fas fa-times"></i></button>
            `;
            
            const categoryContainer = document.getElementById(category);
            categoryContainer.appendChild(skillItem);
            
            skillForm.reset();
            skillLevelValue.textContent = '75%';
            closeModal('skillModal');
        });
    }

    // Delete skill functionality
    document.addEventListener('click', function(e) {
        if (e.target.closest('.delete-skill')) {
            e.target.closest('.skill-item').remove();
        }
    });

    // Project Modal
    const addProjectBtn = document.getElementById('addProjectBtn');
    const projectModal = document.getElementById('projectModal');
    const projectForm = document.getElementById('projectForm');
    const projectsContainer = document.getElementById('projectsContainer');

    if (addProjectBtn && projectModal) {
        addProjectBtn.addEventListener('click', function() {
            openModal('projectModal');
        });
    }

    if (projectForm && projectsContainer) {
        projectForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const title = document.getElementById('projectTitle').value;
            const description = document.getElementById('projectDescription').value;
            const tech = document.getElementById('projectTech').value;
            const github = document.getElementById('projectGithub').value;
            const demo = document.getElementById('projectDemo').value;
            
            const techItems = tech.split(',').map(item => `<span contenteditable="true">${item.trim()}</span>`).join('');
            
            const projectCard = document.createElement('div');
            projectCard.className = 'project-card';
            projectCard.innerHTML = `
                <div class="project-image">
                    <img src="/api/placeholder/400/250" alt="${title}">
                    <div class="edit-overlay">
                        <label class="edit-icon project-image-upload">
                            <i class="fas fa-camera"></i>
                            <input type="file" accept="image/*" style="display: none;">
                        </label>
                    </div>
                </div>
                <div class="project-info">
                    <h3 class="project-title" contenteditable="true">${title}</h3>
                    <p class="project-description" contenteditable="true">${description}</p>
                    <div class="project-tech">
                        ${techItems}
                    </div>
                    <div class="project-links">
                        <a href="${github}" class="project-link" contenteditable="true">
                            <i class="fab fa-github"></i> View Code
                        </a>
                        <a href="${demo}" class="project-link" contenteditable="true">
                            <i class="fas fa-external-link-alt"></i> Live Demo
                        </a>
                    </div>
                    <button class="delete-project"><i class="fas fa-trash"></i></button>
                </div>
            `;
            
            // Add event listener to the new project image upload
            const imageUpload = projectCard.querySelector('.project-image-upload input');
            imageUpload.addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    const projectImage = this.closest('.project-image').querySelector('img');
                    
                    reader.onload = function(event) {
                        projectImage.src = event.target.result;
                    };
                    reader.readAsDataURL(file);
                }
            });
            
            projectsContainer.insertBefore(projectCard, addProjectBtn);
            
            projectForm.reset();
            closeModal('projectModal');
        });
    }

    // Delete project functionality
    document.addEventListener('click', function(e) {
        if (e.target.closest('.delete-project')) {
            e.target.closest('.project-card').remove();
        }
    });

    // Resume file selection display
    const resumeFile = document.getElementById('resumeFile');
    const selectedFileName = document.getElementById('selectedFileName');
    
    if (resumeFile && selectedFileName) {
        resumeFile.addEventListener('change', function() {
            if (this.files.length > 0) {
                selectedFileName.textContent = this.files[0].name;
            } else {
                selectedFileName.textContent = 'No file selected';
            }
        });
    }

    // Resume Upload Form - Updated to work with Node.js API
    const resumeUploadForm = document.getElementById('resumeUploadForm');
    const uploadStatus = document.getElementById('uploadStatus');
    const resumeList = document.getElementById('resumeList');
    
    // Load existing resumes when page loads
    function loadResumes() {
        fetch('/api/resume/list')
            .then(response => response.json())
            .then(data => {
                if (data.success && data.resumes.length > 0) {
                    // Clear the "Your uploaded resumes will appear here" message
                    resumeList.innerHTML = '';
                    
                    // Add each resume to the list
                    data.resumes.forEach(resume => {
                        addResumeToList(resume);
                    });
                }
            })
            .catch(error => {
                console.error('Error loading resumes:', error);
                uploadStatus.className = 'upload-status error';
                uploadStatus.textContent = 'Failed to load resumes. Please try again.';
                
                setTimeout(() => {
                    uploadStatus.textContent = '';
                    uploadStatus.className = 'upload-status';
                }, 3000);
            });
    }
    
    // Helper function to add a resume to the list
    function addResumeToList(resume) {
        const resumeItem = document.createElement('div');
        resumeItem.className = 'resume-item';
        resumeItem.dataset.id = resume.id;
        
        // Format the file size
        const fileSize = formatFileSize(resume.size);
        
        resumeItem.innerHTML = `
            <div class="resume-item-name">
                <i class="fas fa-file-${getFileIcon(resume.filename)}"></i>
                ${resume.filename}
                <span class="file-size">(${fileSize})</span>
            </div>
            <div class="resume-item-actions">
                <button class="download-btn" title="Download" data-id="${resume.id}">
                    <i class="fas fa-download"></i>
                </button>
                <button class="delete-resume-btn" title="Delete" data-id="${resume.id}">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;
        
        resumeList.appendChild(resumeItem);
    }
    
    // Helper function to determine file icon based on extension
    function getFileIcon(filename) {
        const ext = filename.split('.').pop().toLowerCase();
        if (ext === 'pdf') return 'pdf';
        if (ext === 'doc' || ext === 'docx') return 'word';
        return 'alt';
    }
    
    // Helper function to format file size
    function formatFileSize(bytes) {
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
        return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
    }
    
    // Load resumes when page loads
    if (resumeList) {
        loadResumes();
    }
    
    if (resumeUploadForm) {
        resumeUploadForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const fileInput = document.getElementById('resumeFile');
            
            if (fileInput.files.length === 0) {
                uploadStatus.className = 'upload-status error';
                uploadStatus.textContent = 'Please select a file to upload';
                return;
            }
            
            // Show loading status
            uploadStatus.className = 'upload-status loading';
            uploadStatus.textContent = 'Uploading resume...';
            
            // Send the file to the server
            fetch('/api/resume/upload', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    uploadStatus.className = 'upload-status success';
                    uploadStatus.textContent = 'Resume uploaded successfully!';
                    
                    // Clear the "Your uploaded resumes will appear here" message if it exists
                    if (resumeList.querySelector('p')) {
                        resumeList.innerHTML = '';
                    }
                    
                    // Add the uploaded resume to the list
                    addResumeToList({
                        id: data.file.id,
                        filename: data.file.originalName,
                        size: data.file.size
                    });
                    
                    // Reset the form
                    resumeUploadForm.reset();
                    selectedFileName.textContent = 'No file selected';
                } else {
                    uploadStatus.className = 'upload-status error';
                    uploadStatus.textContent = data.message || 'Failed to upload resume';
                }
                
                // Clear status message after 3 seconds
                setTimeout(() => {
                    uploadStatus.textContent = '';
                    uploadStatus.className = 'upload-status';
                }, 3000);
            })
            .catch(error => {
                console.error('Error uploading resume:', error);
                uploadStatus.className = 'upload-status error';
                uploadStatus.textContent = 'Failed to upload resume. Please try again.';
                
                setTimeout(() => {
                    uploadStatus.textContent = '';
                    uploadStatus.className = 'upload-status';
                }, 3000);
            });
        });
    }

    // Handle resume download and delete
    if (resumeList) {
        resumeList.addEventListener('click', function(e) {
            // Delete resume
            if (e.target.closest('.delete-resume-btn')) {
                const deleteBtn = e.target.closest('.delete-resume-btn');
                const resumeId = deleteBtn.dataset.id;
                const resumeItem = deleteBtn.closest('.resume-item');
                
                // Confirm deletion
                if (confirm('Are you sure you want to delete this resume?')) {
                    // Send delete request to the server
                    fetch(`/api/resume/delete/${resumeId}`, {
                        method: 'DELETE'
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Remove the resume from the list
                            resumeItem.remove();
                            
                            // Show success message
                            uploadStatus.className = 'upload-status success';
                            uploadStatus.textContent = 'Resume deleted successfully!';
                            
                            // If no more resumes, show the placeholder text
                            if (resumeList.children.length === 0) {
                                resumeList.innerHTML = '<p>Your uploaded resumes will appear here.</p>';
                            }
                        } else {
                            uploadStatus.className = 'upload-status error';
                            uploadStatus.textContent = data.message || 'Failed to delete resume';
                        }
                        
                        // Clear status message after 3 seconds
                        setTimeout(() => {
                            uploadStatus.textContent = '';
                            uploadStatus.className = 'upload-status';
                        }, 3000);
                    })
                    .catch(error => {
                        console.error('Error deleting resume:', error);
                        uploadStatus.className = 'upload-status error';
                        uploadStatus.textContent = 'Failed to delete resume. Please try again.';
                        
                        setTimeout(() => {
                            uploadStatus.textContent = '';
                            uploadStatus.className = 'upload-status';
                        }, 3000);
                    });
                }
            }
            
            // Download resume
            if (e.target.closest('.download-btn')) {
                const downloadBtn = e.target.closest('.download-btn');
                const resumeId = downloadBtn.dataset.id;
                
                // Create a download link and programmatically click it
                const downloadLink = document.createElement('a');
                downloadLink.href = `/api/resume/download/${resumeId}`;
                downloadLink.download = resumeId; // The server will set the proper filename
                document.body.appendChild(downloadLink);
                downloadLink.click();
                document.body.removeChild(downloadLink);
            }
        });
    }

    // Contact Form
    const contactForm = document.getElementById('contactForm');
    const formStatus = document.getElementById('formStatus');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Simulate an AJAX request
            setTimeout(function() {
                // In a real application, you would send the data to the server
                // This is a mock success response
                formStatus.className = 'form-status success';
                formStatus.textContent = 'Your message has been sent successfully!';
                
                contactForm.reset();
                
                // Clear success message after 3 seconds
                setTimeout(function() {
                    formStatus.textContent = '';
                    formStatus.className = 'form-status';
                }, 3000);
            }, 1500);
        });
    }
});